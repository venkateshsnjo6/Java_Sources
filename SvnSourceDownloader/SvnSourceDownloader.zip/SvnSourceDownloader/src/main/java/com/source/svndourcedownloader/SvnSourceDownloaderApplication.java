package com.source.svndourcedownloader;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SvnSourceDownloaderApplication {

	public static void main(String[] args) {
		SpringApplication.run(SvnSourceDownloaderApplication.class, args);
	}

}
